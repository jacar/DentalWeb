'use client'

import { motion } from 'framer-motion'
import { XCircle, CheckCircle, ArrowRight, TrendingUp } from 'lucide-react'
import { Button } from '@/components/ui/button'

export function ProblemsSection() {
  const problems = [
    {
      problem: 'Pierdes pacientes que buscan dentistas en Google',
      solution: 'Apareces en los primeros resultados con una web optimizada',
      stat: '80%'
    },
    {
      problem: 'Tu competencia tiene web y tú no',
      solution: 'Destacas con un sitio profesional que genera confianza',
      stat: '3x'
    },
    {
      problem: 'Los pacientes no encuentran tu información fácilmente',
      solution: 'Dirección, horarios y servicios claros en un solo lugar',
      stat: '24/7'
    },
    {
      problem: 'Pierdes tiempo respondiendo las mismas preguntas',
      solution: 'FAQ y sistema de citas automático disponible siempre',
      stat: '-60%'
    }
  ]

  const handleWhatsApp = () => {
    const mensaje = encodeURIComponent('Hola! Quiero solucionar estos problemas con una página web profesional.')
    window.open(`https://wa.me/573052891719?text=${mensaje}`, '_blank')
  }

  return (
    <section className="py-20 lg:py-28 bg-gradient-to-b from-gray-50 to-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-[400px] h-[400px] rounded-full bg-teal-50/50 blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-[300px] h-[300px] rounded-full bg-cyan-50/50 blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Header */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 bg-red-50 text-red-600 px-4 py-2 rounded-full text-sm font-medium mb-6">
            <TrendingUp className="w-4 h-4" />
            El Problema es Real
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Sin una Página Web, Pierdes
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-500">
              Pacientes Cada Día
            </span>
          </h2>
          <p className="text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
            El 80% de los pacientes buscan su dentista en internet antes de agendar una cita. 
            Si no apareces, eligieron a tu competencia.
          </p>
        </motion.div>

        {/* Problem/Solution Grid */}
        <div className="grid md:grid-cols-2 gap-6 lg:gap-8 max-w-5xl mx-auto mb-16">
          {problems.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-2xl p-6 lg:p-8 shadow-sm border border-gray-100 hover:shadow-lg hover:border-gray-200 transition-all duration-300"
            >
              {/* Stat badge */}
              <div className="flex justify-between items-start mb-6">
                <div className="w-12 h-12 rounded-xl bg-red-50 flex items-center justify-center">
                  <XCircle className="w-6 h-6 text-red-500" />
                </div>
                <div className="text-right">
                  <span className="text-3xl font-bold text-red-500">{item.stat}</span>
                </div>
              </div>

              {/* Problem */}
              <div className="mb-6">
                <p className="text-sm text-red-600 font-medium mb-1">El Problema</p>
                <p className="text-gray-700 font-medium text-lg">{item.problem}</p>
              </div>

              {/* Divider */}
              <div className="border-t border-dashed border-gray-200 my-6 relative">
                <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 bg-white px-3">
                  <ArrowRight className="w-5 h-5 text-teal-500 rotate-90" />
                </div>
              </div>

              {/* Solution */}
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <CheckCircle className="w-4 h-4 text-emerald-500" />
                </div>
                <div>
                  <p className="text-sm text-emerald-600 font-medium mb-1">La Solución</p>
                  <p className="text-gray-900 font-semibold">{item.solution}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <div className="inline-flex flex-col items-center gap-4">
            <div className="bg-gradient-to-r from-teal-500 to-cyan-500 text-white px-6 py-3 rounded-full text-sm font-medium shadow-lg shadow-teal-500/25">
              ✨ Tu solución está a un clic de distancia
            </div>
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white shadow-lg shadow-green-500/25 px-8"
              onClick={handleWhatsApp}
            >
              Quiero Solucionarlo Ahora
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
