'use client'

import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ArrowRight, Check, Sparkles, Star, Users, Award, Clock, Play } from 'lucide-react'

export function HeroSection() {
  const handleWhatsApp = () => {
    const mensaje = encodeURIComponent('Hola! Me interesa una pagina web para mi clinica dental. Quiero solicitar la demo gratis.')
    window.open(`https://wa.me/573052891719?text=${mensaje}`, '_blank')
  }

  const features = [
    'Dominio .com incluido',
    'Hosting por 1 año',
    'Panel autoadministrable',
    'Mantenimiento gratis',
    'Asesoría 1 año',
    'Sin costos ocultos'
  ]

  return (
    <section className="relative min-h-[90vh] flex items-center overflow-hidden bg-gradient-to-br from-slate-50 via-white to-teal-50">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div 
          className="absolute -top-40 -right-40 w-[600px] h-[600px] rounded-full bg-gradient-to-br from-teal-200/40 to-cyan-200/40 blur-3xl"
          animate={{ 
            scale: [1, 1.1, 1],
            opacity: [0.4, 0.6, 0.4]
          }}
          transition={{ duration: 8, repeat: Infinity }}
        />
        <motion.div 
          className="absolute -bottom-40 -left-40 w-[500px] h-[500px] rounded-full bg-gradient-to-tr from-sky-200/40 to-teal-200/40 blur-3xl"
          animate={{ 
            scale: [1.1, 1, 1.1],
            opacity: [0.5, 0.3, 0.5]
          }}
          transition={{ duration: 10, repeat: Infinity }}
        />
        {/* Grid pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#8882_1px,transparent_1px),linear-gradient(to_bottom,#8882_1px,transparent_1px)] bg-[size:60px_60px]" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Content */}
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center lg:text-left"
          >
            {/* Badge */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1 }}
              className="inline-flex items-center gap-2 mb-6"
            >
              <Badge className="bg-gradient-to-r from-teal-500 to-cyan-500 text-white border-0 px-4 py-2 text-sm font-medium shadow-lg shadow-teal-500/25">
                <Sparkles className="w-4 h-4 mr-1" />
                Demo Gratis en 24 Horas
              </Badge>
            </motion.div>

            {/* Headline */}
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6"
            >
              Tu Clínica Dental
              <span className="block bg-gradient-to-r from-teal-600 to-cyan-600 bg-clip-text text-transparent">
                Merece Destacar
              </span>
            </motion.h1>

            {/* Subheadline */}
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-lg sm:text-xl text-gray-600 mb-8 max-w-xl mx-auto lg:mx-0"
            >
              Diseño web profesional para odontólogos. Dominio, hosting y panel autoadministrable incluido. 
              <span className="font-semibold text-teal-600"> Un solo pago anual, sin sorpresas.</span>
            </motion.p>

            {/* Features Grid */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="grid grid-cols-2 gap-3 mb-8"
            >
              {features.map((feature, index) => (
                <div key={index} className="flex items-center gap-2 text-gray-700">
                  <div className="w-5 h-5 rounded-full bg-teal-100 flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3 text-teal-600" />
                  </div>
                  <span className="text-sm sm:text-base">{feature}</span>
                </div>
              ))}
            </motion.div>

            {/* CTA Buttons */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
            >
              <Button 
                size="lg" 
                className="gap-2 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white shadow-xl shadow-green-500/25 px-8 py-6 text-lg font-semibold rounded-xl transition-all hover:scale-105" 
                onClick={handleWhatsApp}
              >
                <ArrowRight className="w-5 h-5" />
                Solicitar Demo Gratis
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="gap-2 border-2 border-teal-200 text-teal-700 hover:bg-teal-50 hover:border-teal-300 px-8 py-6 text-lg rounded-xl transition-all" 
                onClick={() => document.getElementById('precios')?.scrollIntoView({ behavior: 'smooth' })}
              >
                Ver Planes y Precios
              </Button>
            </motion.div>

            {/* Trust indicators */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
              className="mt-10 pt-8 border-t border-gray-200"
            >
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-6 lg:gap-8">
                <div className="flex items-center gap-2">
                  <div className="flex -space-x-2">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="w-8 h-8 rounded-full bg-gradient-to-br from-teal-400 to-cyan-400 border-2 border-white flex items-center justify-center">
                        <Users className="w-4 h-4 text-white" />
                      </div>
                    ))}
                  </div>
                  <span className="text-sm text-gray-600"><strong className="text-gray-900">200+</strong> clínicas</span>
                </div>
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                  <span className="text-sm text-gray-600 ml-1"><strong className="text-gray-900">4.9</strong></span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Award className="w-5 h-5 text-teal-500" />
                  <span><strong className="text-gray-900">5+ años</strong> de experiencia</span>
                </div>
              </div>
            </motion.div>
          </motion.div>

          {/* Right Content - Video */}
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="relative hidden lg:block"
          >
            {/* Main video container */}
            <div className="relative">
              {/* Background glow */}
              <div className="absolute inset-0 bg-gradient-to-br from-teal-400/20 to-cyan-400/20 rounded-3xl blur-2xl transform scale-110" />
              
              {/* Main video */}
              <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-white/50">
                <video
                  autoPlay
                  loop
                  muted
                  playsInline
                  className="w-full h-auto object-cover"
                  style={{ aspectRatio: '4/3' }}
                >
                  <source src="https://www.webcincodev.com/blog/wp-content/uploads/2026/02/Diseno-sin-titulo-4.mp4" type="video/mp4" />
                </video>
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent" />
                
                {/* Overlay content */}
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                      <Clock className="w-6 h-6 text-white" />
                    </div>
                    <div className="text-white">
                      <p className="text-sm opacity-80">Listo en</p>
                      <p className="text-xl font-bold">7 días hábiles</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Floating price card */}
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7 }}
                className="absolute -bottom-6 -left-6 bg-white rounded-2xl shadow-xl p-5 border border-gray-100"
              >
                <p className="text-xs text-gray-500 mb-1">Desde solo</p>
                <p className="text-3xl font-bold text-gray-900">$400.000</p>
                <p className="text-xs text-teal-600 font-medium">COP / año</p>
              </motion.div>

              {/* Floating demo card */}
              <motion.div 
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8 }}
                className="absolute -top-4 -right-4 bg-gradient-to-br from-amber-400 to-orange-400 rounded-2xl shadow-xl p-4 text-white"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-sm font-bold">Demo Gratis</p>
                    <p className="text-xs text-amber-100">En 24 horas</p>
                  </div>
                </div>
              </motion.div>

              {/* Secondary floating card */}
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.9 }}
                className="absolute top-1/3 -right-4 bg-white rounded-xl shadow-lg p-3 border border-gray-100"
              >
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                    <Check className="w-4 h-4 text-green-600" />
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-gray-900">100% Incluido</p>
                    <p className="text-xs text-gray-500">Dominio + Hosting</p>
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
